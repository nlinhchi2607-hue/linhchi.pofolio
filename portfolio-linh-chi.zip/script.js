/**
 * Portfolio Gia sư Nguyễn Thị Linh Chi - Gamified RPG / Kawaii Arcade
 * JavaScript Controller & Interactive Engine
 */

document.addEventListener('DOMContentLoaded', () => {

  /* ============================================================
     1. WEB AUDIO API 8-BIT RETRO SOUND SYNTHESIZER
     (Zero external audio files needed! Works 100% locally in browser)
     ============================================================ */
  let audioCtx = null;
  let sfxEnabled = true;

  function initAudio() {
    if (!audioCtx) {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (AudioContext) {
        audioCtx = new AudioContext();
      }
    }
    if (audioCtx && audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
  }

  function playSfx(type) {
    if (!sfxEnabled) return;
    try {
      initAudio();
      if (!audioCtx) return;

      const now = audioCtx.currentTime;

      if (type === 'click') {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(580, now);
        osc.frequency.exponentialRampToValueAtTime(800, now + 0.08);
        gain.gain.setValueAtTime(0.12, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.08);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start(now);
        osc.stop(now + 0.08);
      } 
      else if (type === 'coin') {
        // Classic 8-bit coin chime (B5 -> E6)
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(987.77, now); // B5
        osc.frequency.setValueAtTime(1318.51, now + 0.07); // E6
        gain.gain.setValueAtTime(0.15, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.35);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start(now);
        osc.stop(now + 0.35);
      } 
      else if (type === 'levelup') {
        // Fanfare arpeggio (C5 -> E5 -> G5 -> C6)
        const notes = [523.25, 659.25, 783.99, 1046.50];
        notes.forEach((freq, idx) => {
          const osc = audioCtx.createOscillator();
          const gain = audioCtx.createGain();
          osc.type = 'square';
          osc.frequency.setValueAtTime(freq, now + idx * 0.08);
          gain.gain.setValueAtTime(0.1, now + idx * 0.08);
          gain.gain.exponentialRampToValueAtTime(0.01, now + idx * 0.08 + 0.15);
          osc.connect(gain);
          gain.connect(audioCtx.destination);
          osc.start(now + idx * 0.08);
          osc.stop(now + idx * 0.08 + 0.16);
        });
      } 
      else if (type === 'correct') {
        // Victory double chime
        [880, 1174.66].forEach((f, i) => {
          const osc = audioCtx.createOscillator();
          const gain = audioCtx.createGain();
          osc.type = 'triangle';
          osc.frequency.setValueAtTime(f, now + i * 0.1);
          gain.gain.setValueAtTime(0.15, now + i * 0.1);
          gain.gain.exponentialRampToValueAtTime(0.01, now + i * 0.1 + 0.2);
          osc.connect(gain);
          gain.connect(audioCtx.destination);
          osc.start(now + i * 0.1);
          osc.stop(now + i * 0.1 + 0.22);
        });
      } 
      else if (type === 'wrong') {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(220, now);
        osc.frequency.linearRampToValueAtTime(150, now + 0.2);
        gain.gain.setValueAtTime(0.12, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.2);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start(now);
        osc.stop(now + 0.2);
      } 
      else if (type === 'blip') {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(750, now);
        gain.gain.setValueAtTime(0.08, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.05);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start(now);
        osc.stop(now + 0.05);
      }
    } catch (e) {
      // Audio might be blocked until user gesture, safely ignore
    }
  }

  // Bind sound effects to all `.game-sound-btn` elements
  document.querySelectorAll('.game-sound-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const sfx = btn.getAttribute('data-sfx') || 'click';
      playSfx(sfx);
    });
  });

  // SFX Toggle button in HUD
  const sfxToggleBtn = document.getElementById('sfx-toggle');
  const sfxStatus = document.getElementById('sfx-status');
  if (sfxToggleBtn) {
    sfxToggleBtn.addEventListener('click', () => {
      sfxEnabled = !sfxEnabled;
      if (sfxEnabled) {
        if (sfxStatus) sfxStatus.textContent = 'ON';
        sfxToggleBtn.style.opacity = '1';
        playSfx('coin');
        showToast('Âm thanh Trò chơi', 'Đã bật hiệu ứng âm thanh 8-bit sống động 🔊');
      } else {
        if (sfxStatus) sfxStatus.textContent = 'OFF';
        sfxToggleBtn.style.opacity = '0.6';
        showToast('Âm thanh Trò chơi', 'Đã tắt hiệu ứng âm thanh 🔇');
      }
    });
  }


  /* ============================================================
     2. NPC DIALOGUE SYSTEM (CLICK AVATAR TO CHAT)
     ============================================================ */
  const npcBubble = document.getElementById('npc-bubble');
  const npcText = document.getElementById('npc-text');
  const characterAvatarImg = document.getElementById('character-avatar-img');

  const npcQuotes = [
    "Chào mừng bạn đến với thế giới tiếng Anh của Chi! Cùng mình cày cấp nhé! ✨",
    "Đừng lo nếu xuất phát điểm từ Level 1, Chi sẽ cùng bạn cày lên Rank Master! 🌸",
    "Bí kíp săn bẫy đề thi vào lớp 10 đã sẵn sàng, tự tin nhắm 9.0+ nhé! 🎯",
    "Combo IELTS 7.5 + SAT 1460 luôn sẵn sàng hỗ trợ bạn 24/7! 🛡️",
    "Mỗi ngày tích lũy thêm chút EXP từ vựng, kỳ thi nào cũng thành 'chuyện nhỏ'! 📖",
    "Học tiếng Anh bằng bản chất và sự tự tin, bạn sẽ thấy mình tiến bộ vượt bậc từng ngày! 💖"
  ];
  let quoteIdx = 0;

  function advanceNpcQuote() {
    if (!npcText) return;
    quoteIdx = (quoteIdx + 1) % npcQuotes.length;
    npcText.style.opacity = '0';
    playSfx('blip');
    setTimeout(() => {
      npcText.textContent = `"${npcQuotes[quoteIdx]}"`;
      npcText.style.opacity = '1';
    }, 150);
  }

  if (npcBubble) {
    npcBubble.addEventListener('click', advanceNpcQuote);
  }
  if (characterAvatarImg) {
    characterAvatarImg.addEventListener('click', advanceNpcQuote);
  }


  /* ============================================================
     3. TYPING TEXT EFFECT (HERO SECTION)
     ============================================================ */
  const typedTarget = document.getElementById('typed-text');
  const wordsToType = [
    'Gia Sư Tiếng Anh Chuyên Sâu',
    'IELTS 7.5 Academic (IDP/BC)',
    '1460 Điểm Chuẩn Hóa SAT',
    'Sinh viên ĐH Ngoại Thương (FTU)',
    'Cựu học sinh Chuyên Thái Bình'
  ];

  let wordIndex = 0;
  let charIndex = 0;
  let isDeleting = false;
  let typeSpeed = 90;

  function typeEffect() {
    if (!typedTarget) return;

    const currentWord = wordsToType[wordIndex];
    if (isDeleting) {
      typedTarget.textContent = currentWord.substring(0, charIndex - 1);
      charIndex--;
      typeSpeed = 40;
    } else {
      typedTarget.textContent = currentWord.substring(0, charIndex + 1);
      charIndex++;
      typeSpeed = 85;
    }

    if (!isDeleting && charIndex === currentWord.length) {
      typeSpeed = 1800;
      isDeleting = true;
    } else if (isDeleting && charIndex === 0) {
      isDeleting = false;
      wordIndex = (wordIndex + 1) % wordsToType.length;
      typeSpeed = 400;
    }

    setTimeout(typeEffect, typeSpeed);
  }

  typeEffect();


  /* ============================================================
     4. PETAL CANVAS BACKGROUND EFFECT
     ============================================================ */
  const canvas = document.getElementById('petal-canvas');
  let ctx = canvas ? canvas.getContext('2d') : null;
  let petals = [];
  let petalsActive = true;
  let animationFrameId = null;

  function resizeCanvas() {
    if (!canvas) return;
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
  }
  window.addEventListener('resize', resizeCanvas);
  resizeCanvas();

  class Petal {
    constructor() { this.reset(true); }
    reset(initial = false) {
      this.x = Math.random() * (canvas ? canvas.width : window.innerWidth);
      this.y = initial ? Math.random() * (canvas ? canvas.height : window.innerHeight) : -20;
      this.size = Math.random() * 8 + 6;
      this.speedY = Math.random() * 1.1 + 0.5;
      this.speedX = Math.random() * 0.8 - 0.4;
      this.angle = Math.random() * Math.PI * 2;
      this.angularSpeed = (Math.random() - 0.5) * 0.02;
      this.opacity = Math.random() * 0.5 + 0.35;
      this.pinkHue = Math.random() > 0.5 ? '255, 140, 180' : '255, 192, 203';
    }
    update() {
      this.y += this.speedY;
      this.x += this.speedX + Math.sin(this.y * 0.005) * 0.5;
      this.angle += this.angularSpeed;
      if (canvas && (this.y > canvas.height + 20 || this.x > canvas.width + 20 || this.x < -20)) {
        this.reset();
      }
    }
    draw() {
      if (!ctx) return;
      ctx.save();
      ctx.translate(this.x, this.y);
      ctx.rotate(this.angle);
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.bezierCurveTo(this.size / 2, -this.size, this.size, -this.size / 2, this.size, 0);
      ctx.bezierCurveTo(this.size, this.size / 2, this.size / 2, this.size, 0, 0);
      ctx.fillStyle = `rgba(${this.pinkHue}, ${this.opacity})`;
      ctx.fill();
      ctx.restore();
    }
  }

  const PETAL_COUNT = window.innerWidth < 768 ? 18 : 32;
  for (let i = 0; i < PETAL_COUNT; i++) {
    petals.push(new Petal());
  }

  function animatePetals() {
    if (!ctx || !petalsActive) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    petals.forEach(p => { p.update(); p.draw(); });
    animationFrameId = requestAnimationFrame(animatePetals);
  }
  if (canvas) animatePetals();

  const petalToggleBtn = document.getElementById('petal-toggle');
  if (petalToggleBtn) {
    petalToggleBtn.addEventListener('click', () => {
      petalsActive = !petalsActive;
      playSfx('click');
      if (petalsActive) {
        showToast('Hiệu ứng hoa rơi', 'Đã bật hiệu ứng cánh hoa bay lãng mạn 🌸');
        animatePetals();
      } else {
        showToast('Hiệu ứng hoa rơi', 'Đã tạm tắt cánh hoa rơi ✨');
        if (ctx) ctx.clearRect(0, 0, canvas.width, canvas.height);
        cancelAnimationFrame(animationFrameId);
      }
    });
  }


  /* ============================================================
     5. STATS NUMBER COUNTER (INTERSECTION OBSERVER)
     ============================================================ */
  const statNumbers = document.querySelectorAll('.stat-game-num');
  let counted = false;

  const countUp = (el, target, isDecimal = false) => {
    let current = 0;
    const duration = 1600;
    const steps = 50;
    const increment = target / steps;
    const stepTime = duration / steps;

    const timer = setInterval(() => {
      current += increment;
      if (current >= target) {
        current = target;
        clearInterval(timer);
      }
      el.textContent = isDecimal ? current.toFixed(1) : Math.floor(current);
    }, stepTime);
  };

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting && !counted) {
        counted = true;
        statNumbers.forEach(stat => {
          const target = parseFloat(stat.getAttribute('data-target'));
          const isDecimal = stat.getAttribute('data-target').includes('.');
          countUp(stat, target, isDecimal);
        });
      }
    });
  }, { threshold: 0.5 });

  const heroStats = document.querySelector('.hero-stats-game');
  if (heroStats) {
    observer.observe(heroStats);
  }


  /* ============================================================
     6. MINI-GAME: ENGLISH EXP BATTLE (INTERACTIVE QUIZ)
     ============================================================ */
  const quizQuestions = [
    {
      round: "VÒNG 1 / 3: TỪ VỰNG IELTS BAND 7.5+",
      question: "Từ nào sau đây ĐỒNG NGHĨA với từ 'Meticulous'?",
      options: [
        { text: "A. Careless & hasty (Hấp tấp, cẩu thả)", correct: false },
        { text: "B. Highly thorough & careful (Tỉ mỉ, cẩn thận)", correct: true },
        { text: "C. Aggressive & loud (Hung hăng, ồn ào)", correct: false },
        { text: "D. Hesitant & shy (Ngập ngừng, nhút nhát)", correct: false }
      ],
      explanation: "Chính xác! 'Meticulous' có nghĩa là cực kỳ cẩn thận, chi tiết, tỉ mỉ."
    },
    {
      round: "VÒNG 2 / 3: THÀNH NGỮ TIẾNG ANH (IDIOM)",
      question: "Thành ngữ 'A piece of cake' có ý nghĩa là gì?",
      options: [
        { text: "A. Một việc vô cùng dễ dàng", correct: true },
        { text: "B. Món tráng miệng đắt tiền", correct: false },
        { text: "C. Một thử thách rất hóc búa", correct: false },
        { text: "D. Cần sự giúp đỡ của nhiều người", correct: false }
      ],
      explanation: "Tuyệt vời! 'A piece of cake' là thành ngữ chỉ một việc cực kỳ dễ dàng (như 'dễ như ăn kẹo')."
    },
    {
      round: "VÒNG 3 / 3: NGỮ PHÁP THỰC CHIẾN",
      question: "Chọn từ đúng: 'She has been mastering English ___ she was 10 years old.'",
      options: [
        { text: "A. for", correct: false },
        { text: "B. during", correct: false },
        { text: "C. since", correct: true },
        { text: "D. at", correct: false }
      ],
      explanation: "Đỉnh chóp! Dùng 'since' với mốc thời gian trong quá khứ ở thì Hiện tại hoàn thành."
    }
  ];

  let currentQuizIdx = 0;
  let currentScore = 0;
  let canAnswer = true;

  const roundTextEl = document.getElementById('quiz-round-text');
  const questionTextEl = document.getElementById('quiz-question-text');
  const optionsBoxEl = document.getElementById('quiz-options-box');
  const feedbackEl = document.getElementById('quiz-feedback');
  const scoreEl = document.getElementById('quiz-score');
  const playBoxEl = document.getElementById('quiz-play-box');
  const rewardBoxEl = document.getElementById('quiz-reward-box');
  const restartBtn = document.getElementById('quiz-restart-btn');
  const hudExpVal = document.getElementById('hud-exp-val');

  function renderQuizQuestion() {
    if (!questionTextEl || !optionsBoxEl) return;
    canAnswer = true;
    feedbackEl.style.display = 'none';

    const q = quizQuestions[currentQuizIdx];
    roundTextEl.textContent = q.round;
    questionTextEl.textContent = q.question;
    optionsBoxEl.innerHTML = '';

    q.options.forEach((opt, idx) => {
      const btn = document.createElement('button');
      btn.className = 'quiz-opt-btn game-sound-btn';
      btn.textContent = opt.text;
      btn.addEventListener('click', () => handleOptionClick(btn, opt.correct, q.explanation));
      optionsBoxEl.appendChild(btn);
    });
  }

  function handleOptionClick(btn, isCorrect, explanation) {
    if (!canAnswer) return;
    canAnswer = false;

    if (isCorrect) {
      btn.classList.add('correct');
      playSfx('correct');
      currentScore += 100;
      if (scoreEl) scoreEl.textContent = currentScore;
      if (hudExpVal) hudExpVal.textContent = `${9800 + currentScore}/10k`;

      feedbackEl.style.display = 'block';
      feedbackEl.style.background = '#D1FAE5';
      feedbackEl.style.color = '#065F46';
      feedbackEl.style.border = '2px solid #10B981';
      feedbackEl.innerHTML = `🎉 <strong>CHÍNH XÁC (+100 EXP)!</strong> ${explanation}`;

      setTimeout(() => {
        if (currentQuizIdx < quizQuestions.length - 1) {
          currentQuizIdx++;
          renderQuizQuestion();
        } else {
          // Finished all questions!
          showRewardScreen();
        }
      }, 1600);
    } else {
      btn.classList.add('wrong');
      playSfx('wrong');
      feedbackEl.style.display = 'block';
      feedbackEl.style.background = '#FEE2E2';
      feedbackEl.style.color = '#991B1B';
      feedbackEl.style.border = '2px solid #EF4444';
      feedbackEl.innerHTML = `⚠️ <strong>Chưa chính xác rồi!</strong> Thử lại câu tiếp theo nhé.`;

      setTimeout(() => {
        if (currentQuizIdx < quizQuestions.length - 1) {
          currentQuizIdx++;
          renderQuizQuestion();
        } else {
          showRewardScreen();
        }
      }, 1800);
    }
  }

  function showRewardScreen() {
    if (playBoxEl) playBoxEl.style.display = 'none';
    if (rewardBoxEl) rewardBoxEl.style.display = 'block';
    playSfx('levelup');
  }

  if (restartBtn) {
    restartBtn.addEventListener('click', () => {
      currentQuizIdx = 0;
      currentScore = 0;
      if (scoreEl) scoreEl.textContent = '0';
      if (playBoxEl) playBoxEl.style.display = 'block';
      if (rewardBoxEl) rewardBoxEl.style.display = 'none';
      renderQuizQuestion();
    });
  }

  renderQuizQuestion();


  /* ============================================================
     7. SPELL BOOK: WORD OF THE DAY & AUDIO PRONUNCIATION
     ============================================================ */
  const vocabList = [
    {
      word: "Serendipity",
      phonetic: "/ˌser.ənˈdɪp.ə.ti/",
      meaning: "Sự may mắn bất ngờ khi tìm thấy điều tốt đẹp một cách tình cờ.",
      example: "Learning a new language is full of serendipity—you never know what wonderful opportunities it will bring."
    },
    {
      word: "Eloquent",
      phonetic: "/ˈel.ə.kwənt/",
      meaning: "Hùng biện, có khả năng diễn đạt ý tưởng một cách lưu loát và đầy sức thuyết phục.",
      example: "She delivered an eloquent presentation that captivated the entire classroom."
    },
    {
      word: "Resilience",
      phonetic: "/rɪˈzɪl.jəns/",
      meaning: "Khả năng kiên cường, nhanh chóng phục hồi và vượt qua thử thách khó khăn.",
      example: "Success in mastering English requires patience and mental resilience."
    },
    {
      word: "Meticulous",
      phonetic: "/məˈtɪk.jə.ləs/",
      meaning: "Tỉ mỉ, cẩn thận đến từng chi tiết nhỏ nhất.",
      example: "Her meticulous preparation before the IELTS exam helped her achieve Band 7.5 effortlessly."
    },
    {
      word: "Ubiquitous",
      phonetic: "/juːˈbɪk.wɪ.təs/",
      meaning: "Phổ biến ở khắp mọi nơi cùng lúc.",
      example: "English has become ubiquitous in international business and global communication."
    },
    {
      word: "Perseverance",
      phonetic: "/ˌpɜː.sɪˈvɪə.rəns/",
      meaning: "Sự bền bỉ, kiên trì theo đuổi mục tiêu dù gặp nhiều trở ngại.",
      example: "With perseverance and proper guidance, any student can master complex grammar structures."
    },
    {
      word: "A blessing in disguise",
      phonetic: "/ə ˈbles.ɪŋ ɪn dɪsˈɡaɪz/",
      meaning: "(Thành ngữ) Trong cái rủi có cái may; điều tưởng xấu nhưng đem lại kết quả tốt.",
      example: "Failing the mock test was a blessing in disguise as it exposed my weaknesses before the real exam."
    }
  ];

  let currentVocabIdx = 0;
  const wordEl = document.getElementById('vocab-word');
  const phoneticEl = document.getElementById('vocab-phonetic');
  const meaningEl = document.getElementById('vocab-meaning');
  const exampleEl = document.getElementById('vocab-example');
  const counterEl = document.getElementById('vocab-counter');
  const nextSpellBtn = document.getElementById('next-spell-btn');
  const speakBtn = document.getElementById('vocab-speak-btn');

  function renderVocab(idx) {
    if (!wordEl) return;
    const v = vocabList[idx];
    wordEl.style.opacity = '0';
    setTimeout(() => {
      wordEl.textContent = v.word;
      phoneticEl.textContent = v.phonetic;
      meaningEl.textContent = v.meaning;
      exampleEl.innerHTML = `"${v.example.replace(v.word, `<strong>${v.word}</strong>`)}"`;
      if (counterEl) {
        counterEl.textContent = `Từ vựng ${idx + 1} / ${vocabList.length} trong kho tàng IELTS Band 7.5`;
      }
      wordEl.style.opacity = '1';
    }, 150);
  }

  if (nextSpellBtn) {
    nextSpellBtn.addEventListener('click', () => {
      currentVocabIdx = (currentVocabIdx + 1) % vocabList.length;
      renderVocab(currentVocabIdx);
    });
  }

  // Audio Pronunciation using Web Speech API
  if (speakBtn) {
    speakBtn.addEventListener('click', () => {
      const textToSpeak = vocabList[currentVocabIdx].word;
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(textToSpeak);
        utterance.lang = 'en-US';
        utterance.rate = 0.9;
        const voices = window.speechSynthesis.getVoices();
        const enVoice = voices.find(v => v.lang.startsWith('en') && (v.name.includes('Samantha') || v.name.includes('Natural') || v.name.includes('Google') || v.name.includes('Karen')));
        if (enVoice) utterance.voice = enVoice;

        speakBtn.style.transform = 'scale(1.25)';
        utterance.onend = () => { speakBtn.style.transform = 'scale(1)'; };
        window.speechSynthesis.speak(utterance);
      } else {
        showToast('Thông báo', 'Trình duyệt hiện tại chưa hỗ trợ phát âm trực tiếp.');
      }
    });
  }


  /* ============================================================
     8. CONSULTATION BOOKING MODAL & FORMS
     ============================================================ */
  const bookingModal = document.getElementById('booking-modal');
  const closeModalBtn = document.getElementById('modal-close');
  const openBookingBtns = document.querySelectorAll('.open-booking');
  const modalCourseSelect = document.getElementById('modal-course-select');

  function openModal(courseName = '') {
    if (!bookingModal) return;
    if (courseName && modalCourseSelect) {
      modalCourseSelect.value = courseName;
    }
    bookingModal.classList.add('active');
    document.body.style.overflow = 'hidden';
    playSfx('click');
  }

  function closeModal() {
    if (!bookingModal) return;
    bookingModal.classList.remove('active');
    document.body.style.overflow = '';
  }

  openBookingBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const course = btn.getAttribute('data-course') || '';
      openModal(course);
    });
  });

  if (closeModalBtn) closeModalBtn.addEventListener('click', closeModal);
  if (bookingModal) {
    bookingModal.addEventListener('click', (e) => {
      if (e.target === bookingModal) closeModal();
    });
  }
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && bookingModal && bookingModal.classList.contains('active')) closeModal();
  });


  /* ============================================================
     9. TOAST ALERTS & FORM SUBMISSIONS
     ============================================================ */
  const toastMsg = document.getElementById('toast-msg');
  const toastTitle = document.getElementById('toast-title');
  const toastDesc = document.getElementById('toast-desc');
  let toastTimer = null;

  function showToast(title, desc) {
    if (!toastMsg) return;
    if (toastTitle) toastTitle.textContent = title;
    if (toastDesc) toastDesc.textContent = desc;

    toastMsg.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      toastMsg.classList.remove('show');
    }, 4500);
  }

  // Contact Form
  const contactForm = document.getElementById('contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const name = document.getElementById('contact-name').value;
      const phone = document.getElementById('contact-phone').value;
      playSfx('levelup');
      showToast('Báo danh thành công! ⚔️', `Cảm ơn chiến binh ${name}! Gia sư Linh Chi sẽ liên hệ qua Zalo/SĐT ${phone} để gửi đề test nhé.`);
      contactForm.reset();
    });
  }

  // Modal Form
  const modalForm = document.getElementById('modal-form');
  if (modalForm) {
    modalForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const name = document.getElementById('modal-name').value;
      const phone = document.getElementById('modal-phone').value;
      const course = document.getElementById('modal-course-select').value;
      closeModal();
      playSfx('levelup');
      showToast('Nhận nhiệm vụ thành công! 🌟', `Chiến binh ${name} đã chọn [${course}]! Gia sư Linh Chi sẽ sớm phản hồi.`);
      modalForm.reset();
    });
  }


  /* ============================================================
     10. MOBILE MENU & NAVBAR
     ============================================================ */
  const mobileToggle = document.getElementById('mobile-toggle');
  const navMenu = document.getElementById('nav-menu');
  const navLinks = document.querySelectorAll('.nav-link');

  if (mobileToggle && navMenu) {
    mobileToggle.addEventListener('click', () => {
      navMenu.classList.toggle('mobile-open');
      playSfx('click');
      const icon = mobileToggle.querySelector('i');
      if (icon) {
        if (navMenu.classList.contains('mobile-open')) {
          icon.classList.remove('fa-bars');
          icon.classList.add('fa-xmark');
        } else {
          icon.classList.remove('fa-xmark');
          icon.classList.add('fa-bars');
        }
      }
    });

    navLinks.forEach(link => {
      link.addEventListener('click', () => {
        navMenu.classList.remove('mobile-open');
        const icon = mobileToggle.querySelector('i');
        if (icon) {
          icon.classList.remove('fa-xmark');
          icon.classList.add('fa-bars');
        }
      });
    });
  }

  console.log("🎮 Linh Chi's English Quest - Gamified RPG Engine Ready!");
});
